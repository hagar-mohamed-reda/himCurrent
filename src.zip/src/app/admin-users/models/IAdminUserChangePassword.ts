export interface IAdminUserChangePassword {
  adminUserId: string;
  password: string;
  confirmPassword: string;
}
