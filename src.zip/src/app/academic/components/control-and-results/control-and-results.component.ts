import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-control-and-results',
  templateUrl: './control-and-results.component.html',
  styleUrls: ['./control-and-results.component.scss']
})
export class ControlAndResultsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
