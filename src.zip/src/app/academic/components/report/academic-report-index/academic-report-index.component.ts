import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-academic-report-index',
  templateUrl: './academic-report-index.component.html',
  styleUrls: ['./academic-report-index.component.scss']
})
export class AcademicReportIndexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
