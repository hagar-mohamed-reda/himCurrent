import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-registered-report',
  templateUrl: './not-registered-report.component.html',
  styleUrls: ['./not-registered-report.component.scss']
})
export class NotRegisteredReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
