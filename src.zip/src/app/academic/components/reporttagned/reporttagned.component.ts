import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reporttagned',
  templateUrl: './reporttagned.component.html',
  styleUrls: ['./reporttagned.component.scss']
})
export class ReporttagnedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
